Wirevo SDK helper 0.98.1

1. Install Python 3.9+, official Pico SDK (with required submodules), Arm GNU, CMake and Ninja.
2. Extract this ZIP and double-click wirevo-sdk.cmd. First use asks for the installed tool paths.
3. The helper opens Wirevo with a one-time pairing fragment. Wirevo connects automatically. No port, pairing code, JSON selection or companion window is required. Grant the per-site local network permission if the browser asks.
4. Select Resmi Pico SDK, then use Derle. Firmware loads automatically. Use Calistir to start it.

The helper stays open on 127.0.0.1 only. Close its window to stop. CMake runs your trusted project commands as your OS user. No public build service is started.
Configuration and connection files live under LOCALAPPDATA/WirevoSDK on Windows. Connection credentials are not part of project JSON or ZIP exports.
Current native firmware import supports ARM, not Hazard3, and up to 1 MB UF2. Native SDK source-level debugger mapping is not available.
