@echo off
python "%~dp0wirevo-sdk-bridge.py" --setup --open
pause
