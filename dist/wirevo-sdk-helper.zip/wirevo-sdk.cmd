@echo off
python "%~dp0wirevo-sdk-gui.py" --launch
if errorlevel 1 pause
