#include <manual_sdk.h>
#include <hardware/regs/addressmap.h>
unsigned manual_sdk_value(void){return SRAM_BASE==0x20000000u?100:0;}
