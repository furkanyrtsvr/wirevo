Official Raspberry Pi Pico SDK 2.2.0: https://github.com/raspberrypi/pico-sdk/tree/2.2.0
Original hardware/platform_defs.h and hardware/regs/addressmap.h (BSD-3-Clause). manual_sdk.c/h and manifest: Wirevo demonstration. This is a source subset, not the complete SDK.
