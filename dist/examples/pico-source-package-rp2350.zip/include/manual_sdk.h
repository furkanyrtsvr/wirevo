#pragma once
unsigned manual_sdk_value(void);
